#include <Servo.h>

// Define 5 Servo objects
Servo servo1, servo2, servo3, servo4, servo5;
const int servoPins[5] = {A3, 3, A2, 9, 10};  // Change pins if needed

void setup() {
    Serial.begin(9600);  // Start Serial Communication
    while (!Serial);  // 🛑 Wait unt18il Serial is ready

    // Attach servos to pins
    servo1.attach(servoPins[0]);
    servo2.attach(servoPins[1]);
    servo3.attach(servoPins[2]);
    servo4.attach(servoPins[3]);
    servo5.attach(servoPins[4]);

    // Initialize all servos to 0 degrees
    for (int i = 0; i < 5; i++) {
        moveServo(i, 0);
    }
}

void loop() {
    if (Serial.available() > 0) {
        Serial.flush();  // 🛑 Clear buffer before reading
        String data = Serial.readStringUntil('\n');  // Read incoming data
        data.trim();  // Remove spaces or newline characters

        // Parse data into an array of 5 values
        int values[5];
        int index = 0;
        char *ptr = strtok((char *)data.c_str(), ",");
        
        while (ptr != NULL && index < 5) {
            values[index] = atoi(ptr);
            ptr = strtok(NULL, ",");
            index++;
        }

        // Move each servo according to the received values
        for (int i = 0; i < 5; i++) {
            moveServo(i, values[i]);
        }

        // Print the received values for debugging
        Serial.print("Received: ");
        Serial.println(data);
    }
}

// Function to move servo to 0° or 180°
void moveServo(int servoIndex, int position) {
    int angle = (position == 0) ? 0 : 180;  // 0 -> 180°, 1 -> 0°
        int angle1 = (position == 0) ? 180 : 0;
    
    switch (servoIndex) {
        case 0: servo1.write(angle); break;
        case 3: servo4.write(angle); break;
                case 2: servo3.write(angle1); break;
                 case 1: servo2.write(angle1); break;
                case 4: servo5.write(angle1); break;


    }



    switch (servoIndex) {
       
    }

    Serial.print("Servo ");
    Serial.print(servoIndex + 1);
    Serial.print(" moved to ");
    Serial.print(angle);
    Serial.println(" degrees");
}
