import cv2
import time
import numpy as np
from basic import handDetector  # Importing handDetector from basic.py

def fingersUp(lmList):
    """
    Determines which fingers are up.
    Returns an array [Thumb, Index, Middle, Ring, Pinky]
    """
    if len(lmList) == 0:
        return [0, 0, 0, 0, 0]  # No hand detected
    
    tipIds = [4, 8, 12, 16, 20]  # Finger tip landmarks
    fingers = []

    # Thumb: Compare x-coordinates (left vs right hand)
    if lmList[tipIds[0]][1] > lmList[tipIds[0] - 1][1]:  # Thumb tip is right of its base
        fingers.append(1)  # Thumb is up
    else:
        fingers.append(0)

    # Other fingers: Compare y-coordinates
    for i in range(1, 5):
        if lmList[tipIds[i]][2] < lmList[tipIds[i] - 2][2]:  # Finger tip is above its middle joint
            fingers.append(1)  # Finger is up
        else:
            fingers.append(0)

    return fingers

def main():
    cap = cv2.VideoCapture(0)  # Open webcam
    detector = handDetector()

    while True:
        success, img = cap.read()
        if not success:
            print("Failed to grab frame.")
            break

        img = detector.findHands(img)
        lmList = detector.findPosition(img, draw=False)

        fingers = fingersUp(lmList)
        print(f"Fingers Up: {fingers}")

        # Display the array on the screen
        cv2.putText(img, str(fingers), (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1,
                    (0, 255, 0), 2)

        cv2.imshow("Image", img)

        if cv2.waitKey(1) & 0xFF == ord('q'):  # Press 'q' to exit
            break

    cap.release()
    cv2.destroyAllWindows()

if __name__ == "__main__":
    main()
