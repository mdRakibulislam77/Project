import cv2
import mediapipe as mp
import time
import serial  # Import Serial library

# Setup Serial Communication (Change COM port if needed)
try:
    ser = serial.Serial('COM3', 9600, timeout=1)  # Windows: Change to 'COMX' if needed
    time.sleep(2)  # Wait for the serial connection to establish
    print("✅ Serial Connection Established on COM3")
except serial.SerialException as e:
    print(f"❌ Serial Error: {e}")
    ser = None  # Avoid crashing if serial fails

class handDetector():
    def __init__(self, mode=False, maxHands=2, detectionCon=0.5, trackCon=0.5):
        self.mode = mode
        self.maxHands = maxHands
        self.detectionCon = detectionCon
        self.trackCon = trackCon
        self.mpHands = mp.solutions.hands
        self.hands = self.mpHands.Hands(static_image_mode=self.mode,
                                        max_num_hands=self.maxHands,
                                        min_detection_confidence=self.detectionCon,
                                        min_tracking_confidence=self.trackCon)
        self.mpDraw = mp.solutions.drawing_utils
        self.tipIds = [4, 8, 12, 16, 20]  # Landmark IDs for finger tips

    def findHands(self, img, draw=True):
        imgRGB = cv2.cvtColor(img, cv2.COLOR_BGR2RGB)
        self.results = self.hands.process(imgRGB)

        if self.results.multi_hand_landmarks:
            for handLms in self.results.multi_hand_landmarks:
                if draw:
                    self.mpDraw.draw_landmarks(img, handLms,
                                               self.mpHands.HAND_CONNECTIONS)
        return img

    def findPosition(self, img, handNo=0, draw=True):
        lmList = []
        if self.results.multi_hand_landmarks:
            myHand = self.results.multi_hand_landmarks[handNo]
            for id, lm in enumerate(myHand.landmark):
                h, w, c = img.shape
                cx, cy = int(lm.x * w), int(lm.y * h)
                lmList.append([id, cx, cy])
                if draw:
                    cv2.circle(img, (cx, cy), 15, (255, 0, 255), cv2.FILLED)
        return lmList

    def fingersUp(self, lmList):
        """Determines which fingers are up (toggle the logic for 0 and 1)"""
        if len(lmList) == 0:
            return [180, 180, 180, 180, 180]  # No hand detected, set all to 1 (down)

        fingers = []

        # Thumb: Compare x-coordinates (left vs right hand)
        if lmList[self.tipIds[0]][1] > lmList[self.tipIds[0] - 1][1]:  # Thumb tip is right of its base
            fingers.append(0)  # Thumb is up
        else:
            fingers.append(1)

        # Other fingers: Compare y-coordinates
        for i in range(1, 5):
            if lmList[self.tipIds[i]][2] < lmList[self.tipIds[i] - 2][2]:  # Tip is above the middle joint
                fingers.append(0)  # Finger is up
            else:
                fingers.append(1)  # Finger is down

        return fingers

def main():
    cap = cv2.VideoCapture(0)  # Open webcam
    detector = handDetector()
    pTime = 0
    last_sent_time = 0  # Store last time data was sent

    while True:
        success, img = cap.read()
        if not success:
            print("❌ Failed to grab frame.")
            break

        img = detector.findHands(img)
        lmList = detector.findPosition(img, draw=False)
        fingers = detector.fingersUp(lmList)

        # Map finger state (0 -> 0, 1 -> 180)
        mapped_fingers = [0 if finger == 1 else 180 for finger in fingers]

        # Get the current time
        current_time = time.time()

        # Send data every 1 second
        if current_time - last_sent_time >= 1:
            # Convert list to comma-separated string and send to Arduino
            data_str = ','.join(map(str, mapped_fingers)) + '\n'
            print(f"📤 Sending to Serial: {data_str.strip()}")  # Print only the serial data in terminal

            if ser:
                try:
                    ser.write(data_str.encode())  # Send serial data
                    last_sent_time = current_time  # Update last sent time
                except serial.SerialException as e:
                    print(f"❌ Serial Error: {e}")

        # Display the fingers' state on the screen
        cv2.putText(img, str(mapped_fingers), (50, 100), cv2.FONT_HERSHEY_SIMPLEX, 1,
                    (0, 255, 0), 2)

        # Show the image with detected hand and fingers
        cv2.imshow("Hand Detection", img)

        # Wait a short time to avoid flooding serial communication
        time.sleep(0.1)

        # Break the loop when the user presses 'q'
        if cv2.waitKey(1) & 0xFF == ord('q'):  # Press 'q' to exit
            break

    cap.release()
    if ser:
        ser.close()  # Close Serial Connection
        print("🔌 Serial Connection Closed")

if __name__ == "__main__":
    main()
