import serial
import time

ser = serial.Serial('COM3', 9600, timeout=1)  # Change COM3 if needed
time.sleep(2)  # 🛑 Wait for Arduino to initialize

while True:
    data = "0,0,1,1,0\n"  # Example data
    print(f"📤 Sending: {data.strip()}")
    ser.write(data.encode())  # Send data to Arduino
    time.sleep(1)  # Wait before sending aga